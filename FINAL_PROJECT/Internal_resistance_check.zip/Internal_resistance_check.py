import os
import tkinter as tk
from tkinter import messagebox
BATTERY_BASE = {
    "ESP40-12": 7.5,
    "ESP65-12": 5.8,
    "ESP100-12": 3.5,
    "ESP130-12": 3.0,
    "ESP150-12": 2.6,
    "ESP200-12": 2.4,
}
MARGIN = 0.5
filename = "cell_impedance_data.csv"
ui_box = []
def read_battery_data(battery_filename):
    names = []
    values = []
    with open(battery_filename) as f:
        lines = f.readlines()
        for line in lines[1:]:
            tokens = line.strip().split(",")
            if len(tokens) < 2 or tokens[1] == "" or tokens[1] == "-----":
                continue
            names.append(tokens[0])
            values.append(float(tokens[1]))
    return names, values

def judge_battery_data(names, values, selected_model):
    base_val = BATTERY_BASE[selected_model]
    max_val = base_val + MARGIN
    min_val = base_val - MARGIN
    total = 0
    normal = 0
    high_cells = []
    low_cells = []
    for i in range(len(names)):
        name = names[i]
        val = values[i]
        total += 1
        if val > max_val:
            high_cells.append(f"{name} ({val:.2f} mΩ)")
        elif val < min_val:
            low_cells.append(f"{name} ({val:.2f} mΩ)")
        else:
            normal += 1
    res = f"▶ 분석 모델: {selected_model}\n"
    res += f"▶ 정상 범위: {min_val:.1f} ~ {max_val:.1f} mΩ\n"
    res += "-" * 40 + "\n\n"
    res += f"총 검사 개수: {total}개\n"
    res += f"정상 배터리: {normal}개\n"
    res += f"이상 배터리: {len(high_cells) + len(low_cells)}개\n\n"
    if len(high_cells) > 0:
        res += "[경고! 저항 높음 - 교체 의심]\n"
        for cell in high_cells:
            res += f" - {cell}\n"
        res += "\n"
    if len(low_cells) > 0:
        res += "[주의! 저항 낮음]\n"
        for cell in low_cells:
            res += f" - {cell}\n"

    if len(high_cells) == 0 and len(low_cells) == 0:
        res += "모든 배터리가 정상 범위 내에 있습니다!\n"

    return res

def start_analysis():
    if not os.path.exists(filename):
        messagebox.showerror("오류", f"{filename} 파일이 없습니다.")
        return

    selected_model = ui_box[0]
    result_label = ui_box[1]

    names, values = read_battery_data(filename)
    model = selected_model.get()
    report = judge_battery_data(names, values, model)
    result_label.config(text=report)
    
def main():
    root = tk.Tk()
    root.title("배터리 검사 프로그램")
    root.geometry("500x600")
    tk.Label(root, text="분석할 배터리 모델을 선택하세요", font=("", 12)).pack(pady=10)
    selected_model = tk.StringVar()
    selected_model.set("ESP40-12")
    dropdown = tk.OptionMenu(root, selected_model, *BATTERY_BASE.keys())
    dropdown.pack(pady=5)
    btn = tk.Button(root, text="분석 시작", command=start_analysis, bg="lightgray", width=15)
    btn.pack(pady=15)
    result_label = tk.Label(root, text="결과가 여기에 표시됩니다.", justify="left", anchor="n", bg="white", width=55, height=25)
    result_label.pack(pady=10)
    ui_box.append(selected_model)
    ui_box.append(result_label)
    root.mainloop()

if __name__ == "__main__":
    main()