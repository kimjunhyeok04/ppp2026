import requests
import os
import pandas as pd

def download_weather(weather_filename, stid, sy, ey):
    url = f"https://api.taegon.kr/stations/{stid}/?sy={sy}&ey={ey}&format=csv"
    if not os.path.exists(weather_filename):
        resp = requests.get(url)
        with open(weather_filename, "w") as fout:
            fout.write(resp.text)
    else:
        print(f"이미 {weather_filename}이 있습니다.")
def main():
    filename = "./weather_jeonju_1980-2024.csv"
    filename_sw = "./weather_suwon_1980-2024.csv"
    download_weather(filename,146,1980,2024)
    download_weather(filename,119,1980,2024)
    df = pd.read_csv(filename, skipinitialspace=True)
    df_sw = pd.read_csv(filename, skipinitialspace=True)
    df_2019 = df[df["year"] == 2019]
    df_sw_2019 = df_sw[df_sw["year"] == 2019]
    prec_jj = df_2019["rainfall"].sum()
    prec_sw = df_sw_2019["rainfall"].sum()
    diff = abs(prec_jj - prec_sw)
    print(f"2019년도 전주와 수원의 총강수량 차이는 {diff:.1f}mm입니다")
if __name__ == "__main__":
    main()
