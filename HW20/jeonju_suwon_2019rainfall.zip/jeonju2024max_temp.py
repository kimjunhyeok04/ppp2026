import requests
import os
import pandas as pd
def download_weather(weather_filename, stid, sy, ey):
    url = f"https://api.taegon.kr/stations/{stid}/?sy={sy}&ey={ey}&format=csv"
    if not os.path.exists(weather_filename):
        resp = requests.get(url)
        with open(weather_filename, "w") as fout:
            fout.write(resp.text)
    else:
        print(f"이미 {weather_filename}이 있습니다.")
def main():
    filename = "./weather_jeonju_1980-2024.csv"
    download_weather(filename,146,1980,2024)
    df = pd.read_csv(filename, skipinitialspace=True)
    tmax_max = (df[df["year"]==2024]["tmax"].max())
    print(f"2024년도 최고기온은 {tmax_max}도 입니다")
if __name__ == "__main__":
    main()