import pandas as pd
import matplotlib.pyplot as plt
import koreanize_matplotlib
import requests
import os

def download_weather(weather_filename, stid, sy, ey):
    url = f"https://api.taegon.kr/stations/{stid}/?sy={sy}&ey={ey}&format=csv"
    if not os.path.exists(weather_filename):
        resp = requests.get(url)
        with open(weather_filename, "w") as fout:
            fout.write(resp.text)
    else:
        print(f"이미 {weather_filename}이 있습니다.")

def main():
    filename = "./weather_jeonju_1980-2024.csv"
    filename_sw = "./weather_suwon_1980-2024.csv"
    download_weather(filename, 146, 1980, 2024)
    download_weather(filename_sw, 119, 1980, 2024)
    df = pd.read_csv(filename, skipinitialspace=True)
    df_sw = pd.read_csv(filename_sw, skipinitialspace=True)
    avg_jj = df.groupby("year")["tavg"].sum() / df.groupby("year")["tavg"].count()
    avg_sw = df_sw.groupby("year")["tavg"].sum() / df_sw.groupby("year")["tavg"].count()
    plt.figure(figsize=(12,6))
    plt.bar(avg_jj.index, avg_jj.values, label="전주", color="blue")
    plt.bar(avg_sw.index, avg_sw.values, label="수원", color="red")
    plt.title("1980~2024 전주, 수원 평균기온")
    plt.xlabel("연도")
    plt.ylabel("평균기온(°C)")
    plt.legend()
    plt.grid(True)
    plt.savefig("./avg_temp_jeonju_suwon_bar.png")

if __name__ == "__main__":
    main()