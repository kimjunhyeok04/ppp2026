import pandas as pd
import matplotlib.pyplot as plt
import koreanize_matplotlib
import requests
import os

def download_weather(weather_filename, stid, sy, ey):
    url = f"https://api.taegon.kr/stations/{stid}/?sy={sy}&ey={ey}&format=csv"
    if not os.path.exists(weather_filename):
        resp = requests.get(url)
        with open(weather_filename, "w") as fout:
            fout.write(resp.text)
    else:
        print(f"이미 {weather_filename}이 있습니다.")

def main():
    filename = "./weather_jeonju_1980-2024.csv"
    filename_sw = "./weather_suwon_1980-2024.csv"

    download_weather(filename, 146, 1980, 2024)
    download_weather(filename_sw, 119, 1980, 2024)

    df = pd.read_csv(filename, skipinitialspace=True)
    df_sw = pd.read_csv(filename_sw, skipinitialspace=True)

    # 날짜 컬럼 생성 (year, month, day 합치기)
    df["date"] = pd.to_datetime(df[["year","month","day"]])
    df_sw["date"] = pd.to_datetime(df_sw[["year","month","day"]])

    # 생일 날짜(1월 1일)만 추출
    df_day = df[df["date"].dt.strftime("%m-%d") == "01-01"]
    df_sw_day = df_sw[df_sw["date"].dt.strftime("%m-%d") == "01-01"]

    # 그래프 그리기
    plt.figure(figsize=(12,6))
    plt.plot(df_day["year"], df_day["tavg"], marker="o", label="전주", color="blue")
    plt.plot(df_sw_day["year"], df_sw_day["tavg"], marker="o", label="수원", color="red")
    plt.title("매년 1월 1일 평균기온 (전주 vs 수원)")
    plt.xlabel("연도")
    plt.ylabel("평균기온(°C)")
    plt.legend()
    plt.grid(True)
    plt.savefig("./birthday_temp.png")
    plt.show()

    # 1980~2014년 연평균 기온 계산 (전주 기준)
    df_period = df[(df["year"] >= 1980) & (df["year"] <= 2014)]
    avg_by_year = df_period.groupby("year")["tavg"].mean()

    birth_year = 2004
    sorted_years = avg_by_year.sort_values(ascending=False)
    rank = sorted_years.index.get_loc(birth_year) + 1

    print(f"{birth_year}년은 1980~2014년 중 {rank}번째로 더운 해입니다.")
    print(f"가장 더운 해: {sorted_years.index[0]}년")
    print(f"가장 추운 해: {sorted_years.index[-1]}년")

if __name__ == "__main__":
    main()
