import pandas as pd
import matplotlib.pyplot as plt
import koreanize_matplotlib

def main():
    # CSV 불러오기
    df = pd.read_csv("./weather_jeonju_1980-2024.csv", skipinitialspace=True)

    # 날짜 컬럼을 datetime으로 변환
    df["date"] = pd.to_datetime(df["date"])

    # 생일 날짜(1월 1일)만 추출
    df_day = df[df["date"].dt.strftime("%m-%d") == "01-01"]

    # 그래프 그리기
    plt.figure(figsize=(12,6))
    plt.plot(df_day["year"], df_day["tavg"], marker="o", color="blue")
    plt.title("매년 1월 1일 평균기온 (전주)")
    plt.xlabel("연도")
    plt.ylabel("평균기온(°C)")
    plt.grid(True)
    plt.savefig("./birthday_temp.png")
    plt.show()

    # 1980~2014년 연평균 기온 계산
    df_period = df[(df["year"] >= 1980) & (df["year"] <= 2014)]
    avg_by_year = df_period.groupby("year")["tavg"].mean()

    # 본인 태어난 해 (2004년)의 순위
    birth_year = 2004
    sorted_years = avg_by_year.sort_values(ascending=False)
    rank = sorted_years.index.get_loc(birth_year) + 1

    print(f"{birth_year}년은 1980~2014년 중 {rank}번째로 더운 해입니다.")
    print(f"가장 더운 해: {sorted_years.index[0]}년")
    print(f"가장 추운 해: {sorted_years.index[-1]}년")

if __name__ == "__main__":
    main()
