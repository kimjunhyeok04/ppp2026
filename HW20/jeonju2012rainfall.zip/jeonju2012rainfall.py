import requests
import os
import pandas as pd
def download_weather(weather_filename, stid, sy, ey):
    url = f"https://api.taegon.kr/stations/{stid}/?sy={sy}&ey={ey}&format=csv"
    if not os.path.exists(weather_filename):
        resp = requests.get(url)
        with open(weather_filename, "w") as fout:
            fout.write(resp.text)
    else:
        print(f"이미 {weather_filename}이 있습니다.")
def main():
    filename = "./weather_jeonju_1980-2024.csv"
    download_weather(filename,146,1980,2024)
    df = pd.read_csv(filename, skipinitialspace=True)
    rainfall_2012 = df[df["year"] == 2012]["rainfall"].sum()
    print(f"2012년도 전주시 강수량은 {rainfall_2012:.1f}mm입니다")
if __name__ == "__main__":
    main()