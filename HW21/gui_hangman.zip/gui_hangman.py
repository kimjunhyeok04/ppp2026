import PySimpleGUI as sg
import random

def main():
    words = ["apple", "banana", "grape", "orange", "melon"]
    word = random.choice(words)
    life = 6
    result = "_" * len(word)

    layout = [
        [sg.Text("행맨 게임 시작!", size=(20,1))],
        [sg.Text("단어:", size=(10,1)), sg.Text(result, key='-WORD-', size=(20,1))],
        [sg.Text("알파벳 입력:"), sg.Input(key='-GUESS-', size=(5,1)), sg.Button("확인")],
        [sg.Text("남은 목숨:", size=(10,1)), sg.Text(str(life), key='-LIFE-', size=(5,1))],
        [sg.Text("", key='-RESULT-', size=(30,1))],
        [sg.Button("종료")]
    ]

    window = sg.Window("행맨 게임", layout)

    while True:
        event, values = window.read()
        if event == sg.WINDOW_CLOSED or event == "종료":
            break

        elif event == "확인":
            guess = values['-GUESS-'].lower().strip()
            if not guess or len(guess) != 1 or not guess.isalpha():
                window['-RESULT-'].update("한 글자 알파벳만 입력하세요!")
                continue

            if guess in word:
                new_result = ""
                for i in range(len(word)):
                    if word[i] == guess or result[i] != "_":
                        new_result += word[i]
                    else:
                        new_result += "_"
                result = new_result
                window['-RESULT-'].update("맞았습니다!")
            else:
                life -= 1
                window['-RESULT-'].update("틀렸습니다!")
                window['-LIFE-'].update(str(life))

            window['-WORD-'].update(result)
            if "_" not in result:
                window['-RESULT-'].update(f"축하합니다! 정답은 {word}")
            elif life == 0:
                window['-RESULT-'].update(f"게임 오버! 정답은 {word}")

    window.close()

if __name__ == "__main__":
    main()
