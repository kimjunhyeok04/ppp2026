import PySimpleGUI as sg
import random

def main():
    layout =[[sg.Text("로또 번호 뽑기", font=("Helvetica", 16))],
        [sg.Button("번호 생성"), sg.Button("종료")],
        [sg.Text("결과:", size=(10,1)), sg.Text("", key='-RESULT-', size=(30,1))]]
    window = sg.Window("로또 번호 생성기", layout)
    while True:
        event, values = window.read()
        if event == sg.WINDOW_CLOSED or event == "종료":
            break
        elif event == "번호 생성":
            numbers = list(range(1, 46))
            lotto = random.sample(numbers, 6)
            lotto.sort()
            window['-RESULT-'].update(str(lotto))
    window.close()

if __name__ == "__main__":
    main()


