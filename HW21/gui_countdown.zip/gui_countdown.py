import PySimpleGUI as sg
import time
import threading
def countdown(window):
    for i in range(5, 0, -1):
        window['-OUTPUT-'].update(str(i))
        time.sleep(1)
    window['-OUTPUT-'].update("출발")

def main():
    layout = [[sg.Text("카운트다운 결과:", size=(15,1)), sg.Text("", key='-OUTPUT-', size=(10,1))],
        [sg.Button("시작"), sg.Button("종료")]]
    window = sg.Window("카운트다운 GUI", layout)
    while True:
        event, values = window.read()
        if event == sg.WINDOW_CLOSED or event == "종료":
            break
        elif event == "시작":
            threading.Thread(target=countdown, args=(window,), daemon=True).start()
    window.close()
if __name__ == "__main__":
    main()
