import PySimpleGUI as sg
import random

def main():
    score = 0
    num_questions = 2
    layout = [
        [sg.Text("구구단 문제:", size=(15,1)), sg.Text("", key='-QUESTION-', size=(10,1))],
        [sg.Input(key='-ANSWER-', size=(10,1)), sg.Button("확인")],
        [sg.Text("결과:", size=(10,1)), sg.Text("", key='-RESULT-', size=(20,1))],
        [sg.Text("총 점수:", size=(10,1)), sg.Text("0", key='-SCORE-', size=(10,1))],
        [sg.Button("다음 문제"), sg.Button("종료")]
    ]
    window = sg.Window("구구단 퀴즈", layout)
    a = random.randint(2,9)
    b = random.randint(1,9)
    correct_answer = a * b
    window['-QUESTION-'].update(f"{a} x {b}")
    question_count = 1

    while True:
        event, values = window.read()
        if event == sg.WINDOW_CLOSED or event == "종료":
            break

        elif event == "확인":
            try:
                ans = int(values['-ANSWER-'])
                if ans == correct_answer:
                    window['-RESULT-'].update("정답!")
                    score += 50
                else:
                    window['-RESULT-'].update(f"오답! 정답은 {correct_answer}")
                window['-SCORE-'].update(str(score))
            except ValueError:
                window['-RESULT-'].update("숫자를 입력하세요!")

        elif event == "다음 문제":
            if question_count < num_questions:
                a = random.randint(2,9)
                b = random.randint(1,9)
                correct_answer = a * b
                window['-QUESTION-'].update(f"{a} x {b}")
                window['-ANSWER-'].update("")
                window['-RESULT-'].update("")
                question_count += 1
            else:
                window['-RESULT-'].update("퀴즈 종료!")
                window['-QUESTION-'].update("")
                window['-ANSWER-'].update("")

    window.close()

if __name__ == "__main__":
    main()
