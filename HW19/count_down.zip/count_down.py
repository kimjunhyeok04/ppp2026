import time
for i in range(5,0,-1):
    print(i,end="\r")
    time.sleep(1)
print("출발")
