import random
words = ["apple", "banana", "grape", "orange", "melon"]
word = random.choice(words)
life = 6
result = "_" * len(word)
print("행맨 게임 시작!")
print("단어:", result)
while life > 0 and "_" in result:
    guess = input("알파벳 입력: ")
    if guess in word:
        new_result = ""
        for i in range(len(word)):
            if word[i] == guess or result[i] != "_":
                new_result += word[i]
            else:
                new_result += "_"
        result = new_result
        print("맞았습니다!")
    else:
        life -= 1
        print("틀렸습니다! 남은 목숨:", life)
    print("단어:", result)
if "_" not in result:
    print("축하합니다! 정답은:", word)
else:
    print("게임 오버! 정답은:", word)
