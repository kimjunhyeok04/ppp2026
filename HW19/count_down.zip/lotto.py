import random
numbers = list(range(1, 46)) 
lotto = random.sample(numbers, 6)
print("로또 번호:", lotto)
